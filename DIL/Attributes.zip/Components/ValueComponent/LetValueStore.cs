﻿using System;
using System.Collections.Generic;

namespace DIL.Components.ValueComponent
{
    /// <summary>
    /// Centralized storage for LET variables.
    /// </summary>
    public static class LetValueStore
    {
        private static readonly Dictionary<string, object?> _store = new();

        /// <summary>
        /// Stores a variable dynamically.
        /// </summary>
        public static void Set(string key, object? value)
        {
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("Variable name cannot be null or empty.");
            else if (_store.ContainsKey(key))
                throw new Exception($"Variable '{key}' isDefined.");

            _store[key.Trim()] = value;
        }
        /// <summary>
        /// Edit a stored  variable dynamically.
        /// </summary>
        public static void NewSet(string key, object? value)
        {
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("Variable name cannot be empty.");
            else if (!_store.ContainsKey(key))
                throw new Exception($"Variable '{key}' is not Defined.");
            else if (_store[key] is object obl && obl.GetType() != value?.GetType())
                throw new InvalidCastException($"InvalidCastException. Can't cast '{obl.GetType()}' to '{value?.GetType()}'");
            _store[key.Trim()] = value;
        }
        public static Type GetType(string key)
        {
            if (!_store.ContainsKey(key.Trim()))
                throw new Exception($"Variable '{key}' does not exist.");
            return _store[key.Trim()]?.GetType() ?? typeof(object);
        }
        /// <summary>
        /// Retrieves a stored variable.
        /// </summary>
        public static object? Get(string key)
        {
            if (!_store.ContainsKey(key.Trim()))
                throw new Exception($"Variable '{key}' does not exist.");

            return _store[key.Trim()];
        }
        public static bool Contains(string key)=>_store.ContainsKey(key.Trim());
    }
}
