﻿namespace DIL.Attributes
{
    internal class CorePassCurrentLine_IndexAttribute : Attribute
    {
    }
}