﻿namespace DIL.Attributes
{
    [AttributeUsage(AttributeTargets.Parameter)]
    public class CoreUpdateLineByAttribute:Attribute;
   
}