﻿namespace DIL.Attributes
{
    internal class CorePassLinesAttribute : Attribute
    {
    }
}